class Settings:
    API_V1_PREFIX = "/api/v1"
    SECRET_KEY = "dummy"
    ALGORITHM = "HS256"
    STRIPE_SECRET_KEY = "sk_test_dummy"
    STRIPE_RETURN_URL = "https://example.com/return"

settings = Settings() 