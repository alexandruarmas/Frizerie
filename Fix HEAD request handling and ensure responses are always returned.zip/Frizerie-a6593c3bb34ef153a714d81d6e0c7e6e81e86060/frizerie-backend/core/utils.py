def generate_invoice_number():
    return "INV-0001"

def create_pdf_invoice(payment):
    return b"PDFDATA" 