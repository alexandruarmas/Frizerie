import CyberpunkDashboard from "../cyberpunk-dashboard"

export default function Page() {
  return <CyberpunkDashboard />
}
