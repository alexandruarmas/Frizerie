import AdminDashboard from "../components/dashboard"

export default function Home() {
  return <AdminDashboard />
} 