"""
Admin module for the hair salon backend.
""" 