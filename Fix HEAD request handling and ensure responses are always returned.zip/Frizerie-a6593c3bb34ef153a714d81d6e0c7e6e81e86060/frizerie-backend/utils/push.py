def send_push_notification(to, message):
    print(f"[STUB] Sending push notification to {to}: {message}") 