def send_email(to, subject, message):
    print(f"[STUB] Sending email to {to}: {subject} - {message}") 