def send_sms(to, message):
    print(f"[STUB] Sending SMS to {to}: {message}") 