def send_telegram_message(chat_id, message):
    print(f"[STUB] Sending Telegram message to {chat_id}: {message}") 