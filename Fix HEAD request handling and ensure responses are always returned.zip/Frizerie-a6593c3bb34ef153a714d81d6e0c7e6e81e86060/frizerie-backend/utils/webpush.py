def send_web_push(to, message):
    print(f"[STUB] Sending web push to {to}: {message}") 