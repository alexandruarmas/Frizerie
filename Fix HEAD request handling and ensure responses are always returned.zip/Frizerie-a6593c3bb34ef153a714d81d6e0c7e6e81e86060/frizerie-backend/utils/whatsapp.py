def send_whatsapp_message(to, message):
    print(f"[STUB] Sending WhatsApp message to {to}: {message}") 