#!/usr/bin/env bash
pip install --upgrade slowapi==0.1.8 