import { useAuth } from './AuthContext';

export default useAuth; 